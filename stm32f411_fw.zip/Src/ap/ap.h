/*
 * ap.h
 *
 *  Created on: Aug 22, 2021
 *      Author: KMH
 */

#ifndef SRC_AP_AP_H_
#define SRC_AP_AP_H_

#include "hw.h"

void apInit(void);
void apMain(void);

#endif /* SRC_AP_AP_H_ */
