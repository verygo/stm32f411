/*
 * def.h
 *
 *  Created on: Aug 22, 2021
 *      Author: KMH
 */

#ifndef SRC_COMMON_DEF_H_
#define SRC_COMMON_DEF_H_

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>


#define _DEF_LED1           0

#endif /* SRC_COMMON_DEF_H_ */
