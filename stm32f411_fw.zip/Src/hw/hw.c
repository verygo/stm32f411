/*
 * hw.c
 *
 *  Created on: Aug 22, 2021
 *      Author: KMH
 */

#include "hw.h"





void hwInit(void)
{
    bspInit();

    ledInit();

}
