/*
 * hw.h
 *
 *  Created on: Aug 22, 2021
 *      Author: KMH
 */

#ifndef SRC_HW_HW_H_
#define SRC_HW_HW_H_

#include "hw_def.h"

#include "led.h"

void hwInit(void);

#endif /* SRC_HW_HW_H_ */
