/*
 * main.c
 *
 *  Created on: Aug 22, 2021
 *      Author: KMH
 */

#include "main.h"






int main(void)
{
    hwInit();
    apInit();

    apMain();

    return 0;
}
